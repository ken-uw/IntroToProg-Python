
# -------------------------------------------------#
# Title: Test Harness for the Customer App
# Dev:   KenM
# Date:  11/29/2018
# Desc: This application manages customer data
# ChangeLog: (Who, When, What)
#
# -------------------------------------------------#

# Foundations Of Programming: Python
# Instructor: Summer Rae Elasady
# Assignment 08
# 11/29/18

# Much of the code is reused from the module09 word doc
# Employees.py code, modified to work with the imported modules.
# I added a method for loading any existing file data into
# customer list objects, and a counter to display the last
# customer id, cleaned up some of the presentation code, and
# moved the main code into main().

# Import the applicable modules for testing
import Customers, DataProcessor

# Add the variables needed for testing
objE = None  # an Customer object
objF = None  # file object for loading existing file data into customer list objects
intId = 0  # an CustomerId
strFirstName = ""  # an Customer's first name
strLastName = ""  # an Customer's last name
strInput = ""  # temporary user input
FILENAME = "CustomerData.txt"  # Filename of the file used for reading and writing customer data

# Add functions required for testing
def ProcessNewCustomerData(Id, FirstName, LastName):
    """Creates cust obj and appends them to cust obj list"""
    try:
        # Create Customer object
        objE = Customers.Customer()
        objE.Id = Id
        objE.FirstName = FirstName
        objE.LastName = LastName
        Customers.CustomerList.AddCustomer(objE)
    except Exception as e:
        print(e)

def SaveDataToFile():
    """Saves data to CustomerData.txt file"""
    try:
        objF = DataProcessor.File()
        objF.FileName = FILENAME
        objF.TextData = Customers.CustomerList.ToString()
        print("Saving the following data to the " + FILENAME + " text file: \n" + Customers.CustomerList.ToString())
        objF.SaveData()
    except Exception as e:
        print(e)

def OpenFile(file):
    """Accepts filename and returns a file handle in read mode"""
    # I use this to populate the Customers.CustomerList list object
    # with any existing data from the CustomerData.txt file
    try:
        filehandle = open(file, "r")
        return filehandle
    except FileNotFoundError as e:
        print("Error: " + str(e) + "\n Please check the file name")
    except Exception as e:
        print("Error: " + str(e))



# Test the method for opening the CustomerData.txt file
# and loading the existing data into CustomerList object

objF = OpenFile(FILENAME)
for row in objF:
    ProcessNewCustomerData(row.split(',')[0], row.split(',')[1], row.split(',')[2])
objF.close()

# Print out the current data from the CustomerList object
print(Customers.CustomerList.ToString())

# Test creating a new CustomerList object
intId = 9
strFirstName = "FirstName"
strLastName = "LastName\n"
ProcessNewCustomerData(intId, strFirstName, strLastName)

# Print out the updated CustomerList object
print(Customers.CustomerList.ToString())

# Test the SaveDataToFile() method

SaveDataToFile()




