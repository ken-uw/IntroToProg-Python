# -------------------------------------------------#
# Title: Working with Functions and Classes
# Dev: KenM
# Date: Nov 11, 2018
# Version 1.0
# -------------------------------------------------#

# Foundations Of Programming: Python
# Instructor: Summer Rae Elasady
# Assignment 06
# 11/11/18

# New program that reuses code and logic from assignment 05. The code has
# been rewritten as functions and classes. The program loads a file from the
# relative directory, and provides inputs for adding, removing, and saving data
# back to the file. The file ToDo.txt must exist in the current directory, or
# else the program will fail to load


# Data

FILENAME = "ToDo.txt" # file that must exist before starting the program (things to fix in version 1.1)
strChoice = "" # string input from the user
dictRow = {} # dictionary to hold individual task/priority rows
lstTable = [] # list to hold all the dictionary rows

# I/O
# Class of functions for handling user input and console output
class IO:
    @staticmethod
    def display_menu():
        """Display the menu options to the console"""
        print("""
        Menu of Options
        1) Show current data
        2) Add a new item
        3) Remove an existing item
        4) Save Data to File
        5) Exit Program
        """)

    @staticmethod
    def get_choice():
        """Get menu choice from user input"""
        strChoice = input("Which option would you like to perform? [1 to 4] - ").strip() # strip any trailing space before returning
        print()
        return strChoice

    @staticmethod
    def display_list_items(table):
        """Display list items with index numbers"""
        # Remove the first row (header info) from the display output
        # This is not good practice, as it is really specific to this
        # program. Something to fix going forward
        for row in enumerate(table[1:]):
            print(row)

    @staticmethod
    def display_text_items(table):
        """Display task items from the table in 'task,priority' format"""
        print("\nThe table in memeory currently contains the following tasks:\r")
        if int(len(table)) > 1:
            # Remove the first row (header info) from the display output
            # This is not good practice, as it is really specific to this
            # program. Something to fix going forward
            for row in (table[1:]):
                task, prio = (row.values())
                print(task + "," + prio + "\r")
        else:
            print("No tasks currently loaded in memeory.")

    @staticmethod
    def get_task_desc():
        """Get string input from user input"""
        strTask = input("Enter a household task: ")
        while strTask == "":
            strTask = input("Enter a household task: ")
        else:
            strPri = input("Enter a priority for the task - " + strTask.title().strip() + " (low, med, or high): ")
        while strPri == "":
            strPri = input("Enter a priority for the task - " + strTask.title().strip() + " (low, med, or high): ")
        return strTask, strPri

    @staticmethod
    def get_task_index():
        """Get index of list item from user input"""
        return input("\nEnter index number to remove from the list, or press Enter to return to the main menu: ")

    @staticmethod
    def input_file_save():
        """Get file save answer from user input"""
        return input("\n(Enter 'Y/y' to save or 'N/n' to return to the main menu.) ").lower()

# Data Processing
# Classes for the data-handling process for this program
class DataProcessing:
    @staticmethod
    def load_data_from_file():
        """Load FILENAME constant from relative directory"""
        # Load the file found in the FILENAME constant. This is
        # also problematic becuase it does not do any validation.
        # Something to fix in the future
        objFile = open(FILENAME, "r")
        for line in objFile:
            strData = line.split(",") # split comma delineated lines from each line in the ToDo.txt file
            dictRow = {"Task": strData[0], "Priority": strData[1].strip("\n")}
            lstTable.append(dictRow)
        objFile.close()

    @staticmethod
    def add_task_to_list(task, priority, table):
        """Add task/priority items to the listTable"""
        # Takes string input items task and priority and
        # the table list, and appends them to the table in memory
        dictRow = {"Task": str(task).title().strip(), "Priority": str(priority).strip()}
        table.append(dictRow)

    @staticmethod
    def remove_task_from_list(rownum, table):
        """Remove list items via index number"""
        # This is another function that is really program specific in that
        # it assumes that the table contains a header row that does not need
        # to be displayed to the user
        try:
            lstLen = (len(table) -2)
            if int(rownum) > int(lstLen):
                print("\nNot a valid index number. Returning to the main menu...")
            else:
                table.remove(table[int(rownum) +1])
        except:
            # if a number is not entered, return to the main menu
            print("\nIvalid input. Returning to the main menu...")

    @staticmethod
    def save_data_to_file(filename, table):
        """Save items loaded in memory to the FILENAME constant"""
        # Iterate through the dictionary row items and write the data as comma delimited to the file
        # in memory. Each value in a row in dictionary is assigned to 'task' and 'pri', and then written
        # to the file
        objFile = open(filename, "w")
        for row in (table):
            task, prio = (row.values())
            objFile.write(task + "," + prio + "\r")
        for row in (table[1:]): # Remove the first row (header info) from the display output
            task, prio = (row.values())
            print(task + "," + prio + "\r")
        # Write the data from memory to the file
        objFile.close()

###### Main ######
# encapsulated the main program logic in the main function

def main():
    DataProcessing.load_data_from_file() # Call the class.function for opening the ToDo.txt file
    while (True): # The main while loop for menu output/input
        IO.display_menu()
        strChoice = IO.get_choice()

        if strChoice == "1": # display text lines from the ToDo.txt file
            # Display each line in the file by passing the global lstTable list to the class.function
            IO.display_text_items(lstTable)

        elif strChoice == "2": # add tasks to the table list
            # This class.function returns the task and priority strings
            strTask, strPri = IO.get_task_desc()
            # Pass the strings and table to class.function for appending
            DataProcessing.add_task_to_list(strTask, strPri, lstTable)
            IO.display_text_items(lstTable)

        elif strChoice == "3": # remove tasks from the table list
            IO.display_list_items(lstTable) # Call the class.function to display an index numbered list
            rowIndex = IO.get_task_index() # Get the index number
            # Call the class.function and pass the row index # and list
            DataProcessing.remove_task_from_list(rowIndex, lstTable)

        elif strChoice == "4":
            IO.display_text_items(lstTable) # Display the lines of task and priority text items to the console
            if IO.input_file_save() == "y":
                print("\nSaving the following data to the ToDo.txt file:\r")
                DataProcessing.save_data_to_file(FILENAME, lstTable) # Pass the filename constant and table list
            else:
                continue
        elif (strChoice == "5"):
            lstTable.clear() # clear data from memory
            break # break out of the main() function and end program

# Call the main function / start the program
if __name__ == '__main__':
    main()