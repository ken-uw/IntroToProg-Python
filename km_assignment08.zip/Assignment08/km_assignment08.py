# -------------------------------------------------#
# Title: Working with Functions and Classes
# Dev: KenM
# Date: Nov 25, 2018
# Version 1.0
# -------------------------------------------------#

# Foundations Of Programming: Python
# Instructor: Summer Rae Elasady
# Assignment 08
# 11/25/18

# New program that will refactor code, provided by the instructor in the
# assignment08 document, into code that utilizes classes and functions
#

# DATA


class Product(object):
    """product information objects"""

    # --Fields--
    # prodId
    # prodName
    # prodPrice
    __Counter = 0  # add a counter for the number of products added to the file

    # --Constuctor--
    # initialize with 3 attributes and call the static method __SetObjectCount() to increment the object counter
    def __init__(self, id, name, price):
        # Attributes
        self.prodId = id
        self.prodName = name
        self.prodPrice = price
        Product.__SetObjectCount()

    # --Properties--
    # prodID
    @property   # (getter or accessor)
    def prodId(self):
        return self.__prodId.strip()  # strip off any trailing space from the input

    @prodId.setter   # (setter or mutator)
    def prodId(self, value):
        self.__prodId = value

    @property  # (getter or accessor)
    def prodName(self):
        return self.__prodName.strip()  # strip off any trailing space from the input

    @prodName.setter   # (setter or mutator)
    def prodName(self, value):
        self.__prodName = value

    @property  # (getter or accessor)
    def prodPrice(self):
        return self.__prodPrice.strip()  # strip off any trailing space from the input

    @prodPrice.setter   # (setter or mutator)
    def prodPrice(self, value):
        self.__prodPrice = value

    # --Methods--
    # Print the Object's string variables
    def ToString(self):
        return self.prodId + "," + self.prodName + "," + self.prodPrice

    def __str__(self):
        return self.ToString()

    @staticmethod
    def GetObjectCount():
        """Get the number of product objects created"""
        return Product.__Counter

    @staticmethod
    def __SetObjectCount():
        """This private method is called within this class for
        the purpose of incrementing the object counter"""
        Product.__Counter += 1

# End Product class

# Processing
class ProdFileProc():
    """class for processing product data"""

    @staticmethod
    def OpenFile(file):
        """check for existence of a file, and open if the file exists
        returns file handle for file parameter"""
        try:
            filehandle = open(file, "r+")
            return filehandle
        except FileNotFoundError as e:
            print("Error: " + str(e) + "\n Please check the file name")
        except Exception as e:
            print("Error: " + str(e))

    @staticmethod
    def CloseFile(file):
        """accepts a file handle as an argument and
        closes the file"""
        file.close()
        print("Closing the " + file.name + " file " )

    @staticmethod
    def GetFileName(file):
        """returns file name for a file handle"""
        filename = file.name
        return filename

    @staticmethod
    def WriteProductUserInput(File):
        """accepts file handle as an argument and
        writes user input to the file"""
        try:
            print("Type in a Product Id, Name, and Price you want to add to the file")
            print("(Enter 'Exit' to quit!)")
            while True:
                strUserInput = input("Enter the Id, Name, and Price (ex. 1,ProductA,9.99): ")
                # check for exactly 3 splits in the string data before trying to create
                # a new product object
                if len(strUserInput.split(',')) != 3 or strUserInput.lower() == "exit":
                    break
                else:
                    prodObj = Product(strUserInput.split(',')[0], strUserInput.split(',')[1], strUserInput.split(',')[2])
                    File.write(prodObj.__str__() + "\n")
        except Exception as e:
            print("Error: " + str(e))

    @staticmethod
    def ReadAllFileData(File, Message="\nCurrent Contents of the File:"):
        try:
            print(Message)
            File.seek(0)
            print("\n" + File.read())
        except Exception as e:
            print("Error: " + str(e))

# End ProdFileProc class

# Variables
# Constant for the 'Products.txt' file
FILENAME = "Products.txt".lower()

# File handle for the 'Products.txt' file
# Created by calling the ProdFileProc.OpenFile() class/function
objFile = ProdFileProc.OpenFile(FILENAME)

# A string which holds user input
strUserInput = None

# main
def main():
    # Check if the file handle exists, and if not, exit
    if objFile:
        # Read the current file data and then call the class.function that will get user input
        ProdFileProc.ReadAllFileData(objFile, "Here is the current data:")
        ProdFileProc.WriteProductUserInput(objFile)
        # Check for number of product objects created and present applicable message to the user
        if Product.GetObjectCount() > 1:
            ProdFileProc.ReadAllFileData(objFile, "\n" + str(Product.GetObjectCount()) + " new items saved to the "
                                         + ProdFileProc.GetFileName(objFile) + " file.")
            ProdFileProc.CloseFile(objFile)
        elif Product.GetObjectCount() == 1:
            ProdFileProc.ReadAllFileData(objFile, "\n" + str(Product.GetObjectCount()) + " new item saved to the "
                                         + ProdFileProc.GetFileName(objFile) + " file.")
            ProdFileProc.CloseFile(objFile)
        else:
            print("\nNothing new added to the " + objFile.name + " file.")
            ProdFileProc.ReadAllFileData(objFile)
            ProdFileProc.CloseFile(objFile)
    else:
        input("\nPress the enter key to exit.")


if __name__ == '__main__':
    main()
