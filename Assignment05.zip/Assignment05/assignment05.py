# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   KenM, 11/04/2018, Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dictRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
# If no file exists, or the user opens in a different directory
# than the file, create the file with the same data

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all ToDo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# -------------------------------


# import os module for checking if a file exists
import os
objFile = "ToDo.txt"
dictRow = {}
lstTable = []
strData = ""
strTask = ""
strPri = ""
strItem = ""
lstLen = ""
saveDataToFile = ""
numChoice = ""

# Step 1 - Load data from a file
# When the program starts, load each "row" of data in "ToDo.txt" into a python Dictionary.
# Add each dictionary "row" to a python list "table"
# Not really necessary for this assignment but I check for the existence of ToDo.txt
# and if it doesn't exist, I create the file and add the preliminary text
if os.path.isfile(objFile):
    objFile = open("ToDo.txt", "r")
    # Add each line of data from the file to a dictionary, and then add all the dictionary
    # rows to a list. Each time through the loop append each dictionary row to the list
    # Close the file after reading in the contents
    for line in objFile:
        strData = line.split(",")
        dictRow = {"Task": strData[0], "Priority": strData[1].strip("\n")}
        lstTable += [dictRow]
else:
    objFile = open("ToDo.txt", "a")
    objFile.write("Task,Priority\n" + "Clean House,low\n" + "Pay Bills,high\n")
    objFile.close()
    objFile = open("ToDo.txt", "r")
    # Add each line of data from the file to a dictionary, and then add all the dictionary
    # rows to a list. Each time through the loop append each dictionary row to the list
    # Close the file after reading in the contents
    for line in objFile:
        strData = line.split(",")
        dictRow = {"Task": strData[0], "Priority": strData[1].strip("\n")}
        lstTable += [dictRow]

# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item
    3) Remove an existing item
    4) Save Data to File
    5) Exit Program
    """)
    # Add code to ensure that a number is entered. It does not check if the number is one
    # from the list of options. However, the menu will simply redisplay on invalid number
    try:
        numChoice = int(input("Which option would you like to perform? [1 to 4] - "))
        print()  # adding a new line
    except:
        print("Not a number... try again!")
        continue
    else:
        print()  # adding a new line

    # Step 3 -Show the current items in the table
    # I used enumerate to iterate over the dictionary rows in the list and display them on
    # separate lines with the index number prefixed to each row
    if numChoice == 1:
        for row in enumerate(lstTable):
            print(row)

    # Step 4 - Add a new item to the list/Table
    # For the user input, I only check to ensure that data was entered. There is no error checking/handling
    # I used a while loop for each key/value pair that adds data to the list, only if both pairs have data
    elif numChoice == 2:
        strTask = input("Enter a household task: ")
        while strTask == "":
            strTask = input("Enter a household task: ")
        else:
            strPri = input("Enter a priority for the task - " + strTask + " (low, med, or high): ")
        while strPri == "":
            strPri = input("Enter a priority for the task - " + strTask + " (low, med, or high): ")
        else:
            # build new a dictionary row and append it to the lstTable list
            dictRow = {"Task": str(strTask).title(), "Priority": str(strPri)}
            lstTable += [dictRow]

    # Step 5 - Remove a new item from the list/Table
    # I first present the list to the user using the same for loop used in menu option 1. This gives a
    # list of dictionary items numbered appropriately that the user can then choose to remove.
    # I added error handling to check for int. And I also added an if/else statement to verify that
    # the number entered is in the list.
    elif (numChoice == 3):
        for row in enumerate(lstTable):
            print(row)
        try:
            strItem = int(input("\nEnter the number of an item to remove it from the list, or press the Enter key to return to the main menu: "))
            # Get the length of the list and use that to ensure that the number entered is
            # in the list of rows. Subtract one from the list to account for the row indices starting at zero
            lstLen = (len(lstTable) - 1)
            if int(strItem) > int(lstLen):
                print("\nNot a valid index number. Returning to the main menu...")
            else:
                lstTable.remove(lstTable[int(strItem)])
        except:
            # if a number is not entered, return to the main menu
            print("\nA number was not entered. Returning to the main menu...")

    # Step 6 - Save tasks to the ToDo.txt file
    # Present the user with the output from the lstTable and ask if they would like to save the data
    # If yes, display the specific data (values) that are being saved, then save and close the file
    # Used a while loop to ensure that a Y or N is entered and a if/else statement to handle either
    elif (numChoice == 4):
        print("\nWould you like to save the following data to the ToDo.txt file?\n")
        for row in enumerate(lstTable):
            print(row)
        saveDataToFile = input("\n(Enter 'Y/y' to save or 'N/n' to return to the main menu.) ").lower()
        while saveDataToFile != "y" and saveDataToFile != "n":
            saveDataToFile = input("\n(Enter 'Y/y' to save or 'N/n' to return to the main menu.) ").lower()
        # Save the data to the ToDo.txt file and exit, or close the file without saving and exit
        else:
            if saveDataToFile == 'y':
                print("\nSaving the following data to the ToDo.txt file:\n\r")
                # Iterate through the dictionary row items and write the data as comma delimited to the file
                # in memory. Each value in a row in dictionary is assigned to 'task' and 'pri', and then written
                # to the file
                objFile = open("ToDo.txt", "w")
                for row in (lstTable):
                    task, prio = (row.values())
                    objFile.write(task + "," + prio + "\r")
                    print(task + "," + prio + "\r")
                # Write the data from memory to the file
                objFile.close()
            else:
                print("Returning to the main menu...\r\n")
    elif (numChoice == 5):
        if not objFile.closed:
            print("Do you want to save the following data before exiting?\n")
            for row in enumerate(lstTable):
                print(row)
            saveDataToFile = input("\n(Enter 'Y/y' to save or 'N/n' to leave the file unchanged and exit ").lower()
            while saveDataToFile != "y" and saveDataToFile != "n":
                saveDataToFile = input("\n(Enter 'Y/y' to save or 'N/n' to leave the file unchanged and exit) ").lower()
            # Save the data to the ToDo.txt file and exit, or close the file without saving and exit
            else:
                if saveDataToFile == 'y':
                    print("Saving the following data to the ToDo.txt file:")
                    # Iterate through the dictionary row items and write the data as comma delimited to the file
                    # in memory. Each value in a row in dictionary is assigned to 'task' and 'pri', and then written
                    # to the file
                    objFile = open("ToDo.txt", "w")
                    for row in (lstTable):
                        task, prio = (row.values())
                        objFile.write(task + "," + prio + "\r")
                        print(task + "," + prio + "\r")

                    # Write the data from memory to the file
                    objFile.close()
                else:
                    # Clean up the variables and exit the program
                    print("Closing file",objFile.name, "and exiting.\r\n")
                    dictRow = {}
                    lstTable = []
                    strData = ""
                    strTask = ""
                    strPri = ""
                    strItem = ""
                    lstLen = ""
                    saveDataToFile = ""
                    numChoice = ""
                    objFile.close()
            break
        else:
            break  # and Exit the program

